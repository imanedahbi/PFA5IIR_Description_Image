import 'package:flutter/material.dart';
import 'app_colors.dart';

class SidebarStyles {
  // Dimensions
  static const double sidebarWidth = 280.0;
  static const double defaultPadding = 20.0;
  static const double itemSpacing = 10.0;
  static const double iconSize = 22.0;

  // Décoration du sidebar (effet de verre sombre avec bordure néon)
  static BoxDecoration get sidebarDecoration => BoxDecoration(
        color: AppColors.applyAlpha(AppColors.darkBackground, 0.85),
        border: Border(
          right: BorderSide(
            color: AppColors.applyAlpha(AppColors.primaryColor, 0.3),
            width: 1.5,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryColor.withAlpha(51), // 0.2 opacity en alpha
            blurRadius: 30,
            spreadRadius: 5,
            offset: const Offset(0, 0),
          ),
          BoxShadow(
            color: Colors.black.withAlpha(204), // 0.8 opacity en alpha
            blurRadius: 50,
            spreadRadius: -10,
            offset: const Offset(5, 0),
          ),
        ],
      );

  // Décoration des séparateurs
  static BoxDecoration get dividerDecoration => BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.transparent,
            AppColors.primaryColor.withAlpha(128), // 0.5 opacity
            AppColors.secondaryColor.withAlpha(128), // 0.5 opacity
            Colors.transparent,
          ],
        ),
      );

  // Décoration des items de menu par défaut
  static BoxDecoration get menuItemDecoration => BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.transparent,
        border: Border.all(
          color: Colors.transparent,
          width: 1,
        ),
      );

  // Décoration des items de menu au survol (effet néon)
  static BoxDecoration get menuItemHoverDecoration => BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [
            AppColors.applyAlpha(AppColors.primaryColor, 0.1),
            AppColors.applyAlpha(AppColors.secondaryColor, 0.05),
          ],
        ),
        border: Border.all(
          color: AppColors.applyAlpha(AppColors.secondaryColor, 0.4),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.secondaryColor.withAlpha(77), // 0.3 opacity
            blurRadius: 15,
            spreadRadius: 1,
            offset: const Offset(0, 0),
          ),
        ],
      );

  // Style de texte des items de menu par défaut
  static TextStyle get menuItemTextStyle => TextStyle(
        color: AppColors.subtleText,
        fontFamily: 'Roboto Mono',
        fontSize: 13,
        fontWeight: FontWeight.w500,
        letterSpacing: 1.2,
      );

  // Style de texte des items de menu au survol
  static TextStyle get menuItemHoverTextStyle => TextStyle(
        color: Colors.white,
        fontFamily: 'Roboto Mono',
        fontSize: 13,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.2,
        shadows: [
          Shadow(
            color: AppColors.secondaryColor.withAlpha(204), // 0.8 opacity
            blurRadius: 10,
            offset: const Offset(0, 0),
          ),
        ],
      );

  // Couleur des icônes par défaut
  static Color get iconColor => AppColors.subtleText;
}