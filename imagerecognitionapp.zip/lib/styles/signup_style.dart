import 'package:flutter/material.dart';
import 'app_colors.dart';

class SignUpStyles {
  // Colors
  static const Color backgroundColor = AppColors.darkBackground;
  static const Color formFieldText = Colors.white;

  // Spacing
  static const double defaultPadding = 24.0;
  static const double sectionSpacing = 30.0;
  static const double mediumSpacing = 16.0;
  static const double extraLargeSpacing = 40.0;

  // Background decoration (Ambiance cyberpunk sombre)
  static BoxDecoration get backgroundDecoration => const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF0A0A12), // Noir profond
            Color(0xFF121225), // Bleu nuit
            Color(0xFF0A0A12), // Noir profond
          ],
          stops: [0.0, 0.5, 1.0],
        ),
      );

  // Container pour le formulaire (style cyberpunk)
  static BoxDecoration get formContainerDecoration => BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppColors.secondaryColor.withOpacity(0.3),
          width: 1.5,
        ),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.darkBackground.withOpacity(0.9),
            AppColors.darkBackground.withOpacity(0.7),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryColor.withOpacity(0.15),
            blurRadius: 25,
            spreadRadius: 1,
            offset: const Offset(0, 5),
          ),
          BoxShadow(
            color: AppColors.secondaryColor.withOpacity(0.1),
            blurRadius: 10,
            spreadRadius: 0.5,
          ),
        ],
      );

  // Form field decoration (Effet néon)
  static BoxDecoration get formFieldBoxDecoration => BoxDecoration(
        color: AppColors.darkBackground.withOpacity(0.6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.secondaryColor.withOpacity(0.6),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.secondaryColor.withOpacity(0.2),
            blurRadius: 10,
            spreadRadius: 0,
          ),
        ],
      );

  // Button decoration (Bouton Néon Vif - style identique à login)
  static BoxDecoration get buttonDecoration => BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppColors.primaryColor.withOpacity(0.8),
            blurRadius: 20,
            spreadRadius: 2,
            offset: const Offset(0, 0),
          ),
          BoxShadow(
            color: AppColors.secondaryColor.withOpacity(0.6),
            blurRadius: 15,
            spreadRadius: 1,
          ),
        ],
      );

  // Text styles (Police monospace cyberpunk)
  static const TextStyle formFieldTextStyle = TextStyle(
    color: Colors.white,
    fontFamily: 'Roboto Mono',
    fontSize: 16,
    fontWeight: FontWeight.w500,
  );

  // Input decoration avec effet cyberpunk
  static InputDecoration textFieldDecoration({
    required String label,
    required IconData icon,
  }) {
    return InputDecoration(
      labelText: label,
      labelStyle: TextStyle(
        color: AppColors.subtleText.withOpacity(0.8),
        fontFamily: 'Roboto Mono',
        fontSize: 13,
        letterSpacing: 2.0,
        fontWeight: FontWeight.w500,
      ),
      prefixIcon: Icon(
        icon,
        color: AppColors.secondaryColor,
        size: 22,
      ),
      border: InputBorder.none,
      focusedBorder: InputBorder.none,
      enabledBorder: InputBorder.none,
      errorBorder: InputBorder.none,
      disabledBorder: InputBorder.none,
      focusedErrorBorder: InputBorder.none,
      errorStyle: TextStyle(
        color: AppColors.errorColor,
        fontFamily: 'Roboto Mono',
        fontWeight: FontWeight.w500,
        fontSize: 12,
      ),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 18,
      ),
      // Effet de placeholder cyberpunk
      hintStyle: TextStyle(
        color: AppColors.subtleText.withOpacity(0.5),
        fontFamily: 'Roboto Mono',
        fontSize: 14,
      ),
    );
  }

  // Primary button style (Bouton principal)
  static ButtonStyle get primaryButtonStyle => ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        foregroundColor: Colors.white,
        textStyle: const TextStyle(
          fontFamily: 'Roboto Mono',
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: 2.5,
        ),
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 30),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      );

  // Secondary button style (Liens)
  static ButtonStyle get secondaryButtonStyle => TextButton.styleFrom(
        foregroundColor: AppColors.secondaryColor,
        textStyle: const TextStyle(
          fontFamily: 'Roboto Mono',
          fontSize: 14,
          fontWeight: FontWeight.w600,
          letterSpacing: 1.5,
        ),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      );

  // Style pour les titres de section
  static TextStyle get sectionTitleStyle => TextStyle(
        color: AppColors.secondaryColor,
        fontFamily: 'Roboto Mono',
        fontSize: 18,
        fontWeight: FontWeight.w700,
        letterSpacing: 3.0,
      );

  // Style pour les textes d'information
  static TextStyle get infoTextStyle => TextStyle(
        color: AppColors.subtleText,
        fontFamily: 'Roboto Mono',
        fontSize: 12,
        fontWeight: FontWeight.w400,
        letterSpacing: 1.0,
      );
}