import 'package:flutter/material.dart';
import 'app_colors.dart';

// Styles spécifiques à la page Splash
class SplashStyles {
  // Ombre derrière le logo circulaire
  static const List<BoxShadow> logoShadow = [
    BoxShadow(
      color: AppColors.primaryColor,
      blurRadius: 25,
      spreadRadius: 2,
      offset: Offset(0, 5),
    ),
  ];
}
