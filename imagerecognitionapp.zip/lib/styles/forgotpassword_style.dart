import 'package:flutter/material.dart';
import 'app_colors.dart';

class ForgotPasswordStyles {
  // Colors - Maintient la cohérence avec le thème
  static const Color backgroundColor = AppColors.darkBackground;
  static const Color formFieldText = Colors.white;

  // Spacing - Peut être ajusté selon les besoins spécifiques
  static const double defaultPadding = 24.0;
  static const double sectionSpacing = 30.0;
  static const double mediumSpacing = 16.0;
  static const double extraLargeSpacing = 40.0;
  static const double logoSize = 180.0;

  // Background decoration (identique au login pour la cohérence)
  static BoxDecoration get backgroundDecoration => const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF0D0221),
            Color(0xFF021B32),
          ],
        ),
      );

  // Form field decoration (style cohérent avec le login)
  static BoxDecoration get formFieldBoxDecoration => BoxDecoration(
        color: AppColors.applyAlpha(AppColors.primaryColor, 0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.applyAlpha(AppColors.secondaryColor, 0.5),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.applyAlpha(AppColors.primaryColor, 0.1),
            blurRadius: 10,
          ),
        ],
      );

  // Button decoration spécifique pour la réinitialisation
  static BoxDecoration get buttonDecoration => BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFC700FF),
            Color(0xFF00FFFF),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppColors.applyAlpha(AppColors.primaryColor, 0.8),
            blurRadius: 20,
            spreadRadius: 2,
            offset: const Offset(0, 0),
          ),
        ],
      );

  // Style de texte pour le titre principal
  static const TextStyle titleTextStyle = TextStyle(
    color: Colors.white,
    fontSize: 24,
    fontFamily: 'Roboto Mono',
    fontWeight: FontWeight.w700,
    letterSpacing: 2.0,
  );

  // Style de texte pour les messages d'instructions
  static const TextStyle instructionTextStyle = TextStyle(
    fontFamily: 'Roboto Mono',
    color: AppColors.subtleText,
    fontSize: 14,
    letterSpacing: 1.0,
    height: 1.5,
  );

  // Style de texte pour les champs de formulaire
  static const TextStyle formFieldTextStyle = TextStyle(
    color: Colors.white,
    fontFamily: 'Roboto Mono',
    fontSize: 16,
  );

  // Input decoration cohérente
  static InputDecoration textFieldDecoration({
    required String label,
    required IconData icon,
  }) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(
        color: AppColors.subtleText,
        fontFamily: 'Roboto Mono',
      ),
      prefixIcon: Icon(icon, color: AppColors.secondaryColor),
      border: InputBorder.none,
      focusedBorder: InputBorder.none,
      enabledBorder: InputBorder.none,
      errorBorder: InputBorder.none,
      disabledBorder: InputBorder.none,
      focusedErrorBorder: InputBorder.none,
      errorStyle: const TextStyle(
        color: AppColors.errorColor,
        fontFamily: 'Roboto Mono',
      ),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 16,
      ),
    );
  }

  // Button style primaire
  static ButtonStyle get primaryButtonStyle => ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        foregroundColor: Colors.white,
        textStyle: const TextStyle(
          fontFamily: 'Montserrat',
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: 2.0,
        ),
        padding: const EdgeInsets.symmetric(vertical: 18),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      );

  // Button style secondaire (liens)
  static ButtonStyle get secondaryButtonStyle => TextButton.styleFrom(
        foregroundColor: AppColors.secondaryColor,
        textStyle: const TextStyle(
          fontFamily: 'Roboto Mono',
          fontSize: 14,
          fontWeight: FontWeight.w500,
          decoration: TextDecoration.underline,
          decorationColor: AppColors.secondaryColor,
        ),
      );

  // Style spécifique pour le message de confirmation
  static TextStyle get successTextStyle => const TextStyle(
        fontFamily: 'Roboto Mono',
        color: AppColors.secondaryColor,
        fontSize: 12,
        fontWeight: FontWeight.w500,
        letterSpacing: 1.0,
      );

  // Style pour les messages d'erreur
  static TextStyle get errorTextStyle => const TextStyle(
        fontFamily: 'Roboto Mono',
        color: AppColors.errorColor,
        fontSize: 12,
        fontWeight: FontWeight.w500,
      );
}