import 'package:flutter/material.dart';
import 'app_colors.dart';

class ProfileStyles {
  // Spacing
  static const double defaultPadding = 20.0;
  static const double largePadding = 30.0;
  static const double mediumSpacing = 16.0;
  static const double smallSpacing = 8.0;

  // Décoration de fond
  static BoxDecoration get backgroundDecoration => const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF0D0221),
            Color(0xFF021B32),
          ],
        ),
      );

  // Décoration des cartes
  static BoxDecoration get cardDecoration => BoxDecoration(
        color: AppColors.applyAlpha(AppColors.darkBackground, 0.7),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppColors.applyAlpha(AppColors.primaryColor, 0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.applyAlpha(AppColors.primaryColor, 0.1),
            blurRadius: 25,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: Colors.black.withAlpha(100),
            blurRadius: 15,
            spreadRadius: -5,
          ),
        ],
      );

  // Décoration des conteneurs d'input
  static BoxDecoration get inputContainerDecoration => BoxDecoration(
        color: AppColors.applyAlpha(Colors.black, 0.4),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.applyAlpha(AppColors.secondaryColor, 0.2),
          width: 1.5,
        ),
      );

  // Style de titre de section
  static TextStyle get sectionTitleStyle => const TextStyle(
        fontSize: 16,
        fontFamily: 'Roboto Mono',
        fontWeight: FontWeight.w700,
        letterSpacing: 1.5,
        color: Colors.white,
      );

  // Style des labels d'information
  static TextStyle get infoLabelStyle => TextStyle(
        fontSize: 12,
        fontFamily: 'Roboto Mono',
        color: AppColors.subtleText,
        fontWeight: FontWeight.w500,
        letterSpacing: 1.2,
      );

  // Style des valeurs d'information
  static TextStyle get infoValueStyle => const TextStyle(
        fontSize: 15,
        fontFamily: 'Roboto Mono',
        color: Colors.white,
        fontWeight: FontWeight.w600,
      );

  // Style du texte d'input
  static TextStyle get inputTextStyle => const TextStyle(
        color: Colors.white,
        fontFamily: 'Roboto Mono',
        fontSize: 14,
      );

  // Décoration des inputs
  static InputDecoration get inputDecoration => InputDecoration(
        labelStyle: TextStyle(
          color: AppColors.subtleText,
          fontFamily: 'Roboto Mono',
          fontSize: 12,
        ),
        border: InputBorder.none,
        focusedBorder: InputBorder.none,
        enabledBorder: InputBorder.none,
        errorBorder: InputBorder.none,
        disabledBorder: InputBorder.none,
        focusedErrorBorder: InputBorder.none,
        errorStyle: TextStyle(
          color: AppColors.errorColor,
          fontFamily: 'Roboto Mono',
          fontSize: 11,
        ),
        contentPadding: const EdgeInsets.symmetric(vertical: 12),
      );

  // Décoration du bouton principal
  static BoxDecoration get primaryButtonDecoration => BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppColors.applyAlpha(AppColors.primaryColor, 0.8),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      );

  // Style du bouton principal
  static ButtonStyle get primaryButtonStyle => ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        foregroundColor: Colors.white,
        textStyle: const TextStyle(
          fontFamily: 'Montserrat',
          fontSize: 16,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2,
        ),
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      );

  // Décoration du bouton secondaire
  static BoxDecoration get secondaryButtonDecoration => BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.applyAlpha(AppColors.secondaryColor, 0.8),
            AppColors.applyAlpha(AppColors.primaryColor, 0.4),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.secondaryColor,
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.applyAlpha(AppColors.secondaryColor, 0.4),
            blurRadius: 15,
            spreadRadius: 1,
          ),
        ],
      );

  // Style du bouton secondaire
  static ButtonStyle get secondaryButtonStyle => ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        foregroundColor: Colors.white,
        textStyle: const TextStyle(
          fontFamily: 'Montserrat',
          fontSize: 16,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2,
        ),
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      );

  // Décoration du bouton succès
  static BoxDecoration get successButtonDecoration => BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.applyAlpha(AppColors.secondaryColor, 0.9),
            AppColors.applyAlpha(Color(0xFF00FFAA), 0.7),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppColors.applyAlpha(AppColors.secondaryColor, 0.6),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      );

  // Style du bouton succès
  static ButtonStyle get successButtonStyle => ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        foregroundColor: Colors.white,
        textStyle: const TextStyle(
          fontFamily: 'Montserrat',
          fontSize: 16,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2,
        ),
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      );

  // Style de texte du titre
  static TextStyle get titleTextStyle => const TextStyle(
        fontSize: 24,
        fontFamily: 'Roboto Mono',
        fontWeight: FontWeight.w800,
        letterSpacing: 2.0,
        color: Colors.white,
      );

  // Couleur de fond
  static Color get backgroundColor => AppColors.darkBackground;
}