import 'package:flutter/material.dart';
import 'app_colors.dart';

class HomeStyle {
  // Dimensions
  static const double sidebarWidth = 280.0;
  static const double defaultPadding = 16.0;
  static const double mediumSpacing = 12.0;
  static const double largeSpacing = 24.0;



  static double getBottomPadding(BuildContext context) {
    return MediaQuery.of(context).padding.bottom + 15;
  }
  // Décoration de fond (identique au login)
  static BoxDecoration get backgroundDecoration => const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF0D0221),
            Color(0xFF021B32),
          ],
        ),
      );

  // Décoration de la carte d'importation (optimisée mobile)
  static BoxDecoration get importCardDecoration => BoxDecoration(
        color: AppColors.applyAlpha(AppColors.darkBackground, 0.7),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppColors.applyAlpha(AppColors.secondaryColor, 0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.applyAlpha(AppColors.primaryColor, 0.1),
            blurRadius: 20,
            spreadRadius: 3,
          ),
          BoxShadow(
            color: Colors.black.withAlpha(128), // 0.5 opacity
            blurRadius: 10,
            spreadRadius: -3,
          ),
        ],
      );

  // Décoration de la barre de contrôle inférieure (mobile friendly)
  static BoxDecoration get controlBarDecoration => BoxDecoration(
        color: AppColors.applyAlpha(AppColors.darkBackground, 0.9),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: AppColors.applyAlpha(AppColors.primaryColor, 0.3),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(179), // 0.7 opacity
            blurRadius: 20,
            spreadRadius: 3,
            offset: const Offset(0, 5),
          ),
          BoxShadow(
            color: AppColors.applyAlpha(AppColors.primaryColor, 0.15),
            blurRadius: 15,
            spreadRadius: 1,
            offset: const Offset(0, 0),
          ),
        ],
      );

  // Décoration de l'affichage de fichier
  static BoxDecoration get fileDisplayDecoration => BoxDecoration(
        color: AppColors.applyAlpha(Colors.black, 0.4),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: AppColors.applyAlpha(AppColors.secondaryColor, 0.2),
          width: 1.2,
        ),
      );

  // Décoration du bouton Analyser
  static BoxDecoration get analyzeButtonDecoration => BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: AppColors.applyAlpha(AppColors.primaryColor, 0.8),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      );

  // Style du bouton Analyser (mobile optimized)
  static ButtonStyle get analyzeButtonStyle => ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        shadowColor: Colors.transparent,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(
          horizontal: 24,
          vertical: 14,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        disabledBackgroundColor: Colors.grey.shade800.withAlpha(128), // 0.5 opacity
        disabledForegroundColor: Colors.grey.shade500,
      );

  // Style pour les textes d'entrée (si nécessaire)
  static const TextStyle inputText = TextStyle(
    color: Colors.white,
    fontFamily: 'Roboto Mono',
    fontSize: 14,
    fontWeight: FontWeight.w500,
  );

  // Couleur de fond pour les inputs
  static Color get inputBackground =>
      AppColors.applyAlpha(AppColors.primaryColor, 0.05);

  // Couleur de bordure pour les inputs
  static Color get inputBorder =>
      AppColors.applyAlpha(AppColors.secondaryColor, 0.5);

  // Couleur des icônes
  static Color get iconColor => AppColors.secondaryColor;

  // Couleur de fond globale
  static Color get backgroundColor => AppColors.darkBackground;

  // Tailles de police responsive
  static double getTitleFontSize(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width < 380) return 22.0;
    if (width < 600) return 26.0;
    return 32.0;
  }

  static double getSubtitleFontSize(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width < 380) return 16.0;
    if (width < 600) return 18.0;
    return 22.0;
  }
}