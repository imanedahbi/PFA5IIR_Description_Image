import 'package:flutter/material.dart';

class AppColors {
  // Couleurs principales (Thème Cyberpunk/Néon)
  static const Color primaryColor = Color(0xFFC700FF); // Magenta/Violet Vif (pour le Néon)
  static const Color secondaryColor = Color(0xFF00FFFF); // Cyan Électrique (pour l'accentuation)

  // Couleurs de Fond et de Texte
  static const Color darkBackground = Color(0xFF0D0221); // Fond très sombre (presque noir)
  static const Color accentColor = Color(0xFFC700FF); // Utilise la couleur primaire pour l'accentuation
  static const Color subtleText = Color(0xFFB392AC); // Texte légèrement délavé
  static const Color errorColor = Color(0xFFFF0055); // Rouge vif pour les erreurs

  // Dégradé principal (Néon Violet/Cyan)
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFFC700FF), // Violet/Magenta Vif
      Color(0xFF00FFFF), // Cyan Électrique
    ],
  );

  // Méthode pour appliquer une transparence à une couleur
  static Color applyAlpha(Color color, double alpha) {
    return color.withAlpha((alpha * 255).round());
  }
}