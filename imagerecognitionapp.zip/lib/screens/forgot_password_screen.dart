import 'package:flutter/material.dart';
import '../styles/forgotpassword_style.dart';
import '../styles/app_colors.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final TextEditingController _emailController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ForgotPasswordStyles.backgroundColor,
      body: SafeArea(
        child: Container(
          decoration: ForgotPasswordStyles.backgroundDecoration,
          child: Padding(
            padding: const EdgeInsets.all(ForgotPasswordStyles.defaultPadding),
            child: SingleChildScrollView(
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 40),

                    // Logo
                    Center(
                      child: Image.asset(
                        'assets/images/imagerecognitionApp.png',
                        width: ForgotPasswordStyles.logoSize,
                        height: ForgotPasswordStyles.logoSize,
                        fit: BoxFit.contain,
                        color: AppColors.primaryColor,
                      ),
                    ),

                    const SizedBox(height: 20),

                    // Titre avec dégradé
                    ShaderMask(
                      shaderCallback: (bounds) =>
                          AppColors.primaryGradient.createShader(bounds),
                      child: const Text(
                        "RÉINITIALISATION // SYSTEM RECOVERY",
                        style: ForgotPasswordStyles.titleTextStyle,
                        textAlign: TextAlign.center,
                      ),
                    ),

                    const SizedBox(height: 25),

                    // Message d'instructions
                    Text(
                      "ENTREZ VOTRE EMAIL POUR RECEVOIR LE LIEN DE RÉINITIALISATION DU SYSTÈME.",
                      textAlign: TextAlign.center,
                      style: ForgotPasswordStyles.instructionTextStyle,
                    ),

                    const SizedBox(height: 40),

                    // Champ Email
                    Container(
                      decoration: ForgotPasswordStyles.formFieldBoxDecoration,
                      child: TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        style: ForgotPasswordStyles.formFieldTextStyle,
                        decoration: ForgotPasswordStyles.textFieldDecoration(
                          label: 'EMAIL',
                          icon: Icons.alternate_email,
                        ),
                        validator: (value) =>
                            value!.isEmpty ? 'ENTREZ VOTRE EMAIL' : null,
                      ),
                    ),

                    const SizedBox(height: ForgotPasswordStyles.extraLargeSpacing),

                    // Bouton Envoyer
                    SizedBox(
                      width: double.infinity,
                      child: DecoratedBox(
                        decoration: ForgotPasswordStyles.buttonDecoration,
                        child: ElevatedButton(
                          onPressed: () {
                            if (_formKey.currentState!.validate()) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'LIEN DE RÉINITIALISATION ENVOYÉ // CHECK YOUR EMAIL',
                                    style: ForgotPasswordStyles.successTextStyle,
                                  ),
                                  backgroundColor: AppColors.primaryColor,
                                  behavior: SnackBarBehavior.floating,
                                ),
                              );
                            }
                          },
                          style: ForgotPasswordStyles.primaryButtonStyle,
                          child: const Text("ENVOYER LE LIEN"),
                        ),
                      ),
                    ),

                    const SizedBox(height: ForgotPasswordStyles.defaultPadding),

                    // Lien retour
                    Center(
                      child: TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        style: ForgotPasswordStyles.secondaryButtonStyle,
                        child: const Text("RETOUR À LA CONNEXION"),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}