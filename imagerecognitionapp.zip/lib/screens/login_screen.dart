import 'package:flutter/material.dart';
import 'home_screen.dart';
import '../services/api_service.dart';
import 'signup_screen.dart';
import 'forgot_password_screen.dart';
import '../styles/login_style.dart';
import '../styles/app_colors.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  Future<void> _login() async {
    if (_formKey.currentState!.validate()) {
      final result = await ApiService.login(
        _emailController.text.trim(),
        _passwordController.text.trim(),
      );

      if (!mounted) return;

      if (result['success'] == true) {
        // Stocker l'ID utilisateur
        final userId = result['user']['id'];
        
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => HomeScreen(userId: userId)),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result['message'] ?? 'Erreur inconnue')),
        );
      }
    }
  }
  // FIN DU CODE SENSIBLE AU BACKEND - NON MODIFIÉ

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: LoginStyles.backgroundColor,
      body: SafeArea(
        child: Container(
          decoration: LoginStyles.backgroundDecoration,
          child: Padding(
            padding: const EdgeInsets.all(LoginStyles.defaultPadding),
            child: SingleChildScrollView(
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 5),  // ← Réduit de 40 à 20

// Logo avec effet néon identique à la sidebar
Center(
  child: ShaderMask(
    shaderCallback: (bounds) =>
        AppColors.primaryGradient.createShader(bounds),
    child: Image.asset(
      'assets/images/imagerecognitionApp.png',
      width: 180,
      height: 180,
      fit: BoxFit.contain,
      color: Colors.white,
    ),
  ),
),

const SizedBox(height: 2),  // ← Réduit de 10 à 5

// Titre CYBER SCAN AI (style identique à la sidebar)
Center(
  child: ShaderMask(
    shaderCallback: (bounds) =>
        AppColors.primaryGradient.createShader(bounds),
    child: const Text(
      "CYBER SCAN AI",
      style: TextStyle(
        fontSize: 30,
        fontFamily: 'Roboto Mono',
        fontWeight: FontWeight.w800,
        letterSpacing: 3.0,
        color: Colors.white,
      ),
    ),
  ),
),

const SizedBox(height: 2),  // ← Réduit de 5 à 2

// Sous-titre style cyberpunk
Center(
  child: Text(
    "SECURE ACCESS PROTOCOL",
    style: TextStyle(
      color: AppColors.secondaryColor,
      fontFamily: 'Roboto Mono',
      fontSize: 14,
      letterSpacing: 3.0,
      fontWeight: FontWeight.w500,
    ),
  ),
),

const SizedBox(height: 15),  // ← Réduit de 30 à 15

// Séparateur style scanline (identique à la sidebar)
Container(
  height: 1,
  margin: const EdgeInsets.symmetric(horizontal: 40),
  decoration: BoxDecoration(
    gradient: LinearGradient(
      colors: [
        Colors.transparent,
        AppColors.primaryColor,
        AppColors.secondaryColor,
        AppColors.primaryColor,
        Colors.transparent,
      ],
    ),
  ),
),

const SizedBox(height: 20),  // ← Réduit de 40 à 20

                    // Conteneur cyberpunk pour le formulaire
                    Container(
                      padding: const EdgeInsets.all(28),
                      decoration: LoginStyles.formContainerDecoration,
                      child: Column(
                        children: [
                          
                          // Champ Email
                          Container(
                            decoration: LoginStyles.formFieldBoxDecoration,
                            child: TextFormField(
                              controller: _emailController,
                              keyboardType: TextInputType.emailAddress,
                              style: LoginStyles.formFieldTextStyle,
                              decoration: LoginStyles.textFieldDecoration(
                                label: 'EMAIL',
                                icon: Icons.alternate_email,
                              ),
                              validator: (value) =>
                                  value!.isEmpty ? 'Entrez votre email' : null,
                            ),
                          ),

                          const SizedBox(height: LoginStyles.mediumSpacing),

                          // Champ Mot de passe
                          Container(
                            decoration: LoginStyles.formFieldBoxDecoration,
                            child: TextFormField(
                              controller: _passwordController,
                              obscureText: true,
                              style: LoginStyles.formFieldTextStyle,
                              decoration: LoginStyles.textFieldDecoration(
                                label: 'PASSWORD',
                                icon: Icons.vpn_key_outlined,
                              ),
                              validator: (value) => value!.isEmpty
                                  ? 'Entrez votre mot de passe'
                                  : null,
                            ),
                          ),

                          const SizedBox(height: 15),

                          // Lien Mot de passe oublié
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) =>
                                          const ForgotPasswordScreen()),
                                );
                              },
                              style: LoginStyles.secondaryButtonStyle,
                              child: const Text("MOT DE PASSE OUBLIÉ ?"),
                            ),
                          ),

                          const SizedBox(height: LoginStyles.extraLargeSpacing),

                          // Bouton Se connecter avec effet néon
                          SizedBox(
                            width: double.infinity,
                            child: DecoratedBox(
                              decoration: LoginStyles.buttonDecoration,
                              child: ElevatedButton(
                                onPressed: _login,
                                style: LoginStyles.primaryButtonStyle,
                                child: const Text("ACCESS GRANTED"),
                              ),
                            ),
                          ),

                          const SizedBox(height: 25),

                          // Séparateur
                          Container(
                            height: 1,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  AppColors.applyAlpha(
                                      AppColors.primaryColor, 0.3),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),

                          const SizedBox(height: 25),

                          // Lien vers Inscription
                          Center(
                            child: TextButton(
                              onPressed: () {
                                if (!mounted) return;
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => const SignUpScreen()),
                                );
                              },
                              style: LoginStyles.secondaryButtonStyle,
                              child: const Text("NEW USER? CREATE ACCOUNT"),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 40),

                    // Footer style cyberpunk
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppColors.applyAlpha(
                              AppColors.secondaryColor, 0.2),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Indicateur de connexion
                          Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: AppColors.primaryGradient,
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppColors.secondaryColor
                                          .withAlpha(120),
                                      blurRadius: 6,
                                      spreadRadius: 1,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                "SYSTEM: ONLINE",
                                style: TextStyle(
                                  color: AppColors.subtleText,
                                  fontFamily: 'Roboto Mono',
                                  fontSize: 11,
                                  letterSpacing: 1.0,
                                ),
                              ),
                            ],
                          ),

                          // Version
                          
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}