import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../styles/home_style.dart';
import 'profile_screen.dart';
import '../widgets/sidebar_widget.dart';
import '../styles/app_colors.dart';
import 'login_screen.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../services/image_service.dart';
// import 'dart:typed_data';
import '../services/api_service.dart';

class HomeScreen extends StatefulWidget {
  final int userId;
  const HomeScreen({super.key, required this.userId});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Uint8List? _imageBytes;
  List<Map<String, String>> messages = [];
  int? currentChatId;
  String? _selectedFileName;

  final ScrollController _scrollController = ScrollController(); // ✅ ICI
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  // ignore: unused_field
  final ImageService _imageService = ImageService();

  @override
  void initState() {
    super.initState();
    _initializeFirstChat();
  }

  Future<void> _initializeFirstChat() async {
    try {
      final response = await http.get(Uri.parse(
        "${ApiService.baseUrl}/get_chats.php?user_id=${widget.userId}"
      ));
      
      if (response.statusCode != 200) {
        throw Exception("HTTP ${response.statusCode}: ${response.body}");
      }

      final data = jsonDecode(response.body);

      
      if (data['success'] && data['chats'].isNotEmpty && mounted) {
        final lastChat = data['chats'][0];
        setState(() {
          currentChatId = lastChat['id'];
        });
        await _loadMessages(currentChatId!);
      } else if (mounted) {
        await _newChat();
      }
    } catch (e) {
      debugPrint("Erreur initialisation chat: $e");
      if (mounted) {
        await _newChat();
      }
    }
  }

  Future<void> _newChat() async {
    try {
      final checkResponse = await http.get(Uri.parse(
        "${ApiService.baseUrl}/get_chats.php?user_id=${widget.userId}"
      ));
      
      final checkData = jsonDecode(checkResponse.body);
      final bool hasActiveChats = checkData['success'] && checkData['chats'].isNotEmpty;

      final response = await http.post(
  Uri.parse("${ApiService.baseUrl}/create_chat.php"),
  headers: {"Content-Type": "application/json"},
  body: jsonEncode({
    "user_id": widget.userId,
    "title": "Conversation ${DateTime.now().toString().substring(0, 16)}",
    "archive_existing": hasActiveChats,
  }),
);

// 🔹 AJOUT POUR DEBUG
print("STATUS CODE = ${response.statusCode}");
print("RESPONSE BODY = ${response.body}");

// Ensuite seulement tu décodes le JSON
    if (response.statusCode != 200) {
      throw Exception("HTTP ${response.statusCode}: ${response.body}");
    }

    final data = jsonDecode(response.body);



      if (data['success'] && mounted) {
        setState(() {
          messages.clear();
          _imageBytes = null;
          _selectedFileName = null;
          currentChatId = data['chat_id']; 
        });
        _scrollToBottom(animated: false);


        if (mounted) {
          _showSnackBar('Nouveau chat créé', Colors.green);
        }
      } else {
        debugPrint("Erreur création chat: ${data['message']}");
        // if (mounted) {
        //   _showSnackBar('Erreur création chat', Colors.red);
        // }
      }
    } catch (e) {
      debugPrint("Exception _newChat: $e");
      if (mounted) {
        _showSnackBar('Erreur réseau: $e', Colors.red);
      }
    }
  }

  Future<void> _sendImageToBackend(Uint8List imageBytes, int chatId) async {
  try {
    final data = await ApiService.sendImageToBackend(imageBytes, chatId, widget.userId);
    if (!data['success']) {
      debugPrint("Erreur insertion image: ${data['message']}");
    } else {
      debugPrint("Image envoyée avec succès: ${data['image_url']}");
    }
  } catch (e) {
    debugPrint("Erreur envoi image: $e");
  }
}


  Future<void> _sendTextToBackend(String text, int chatId) async {
    try {
      final response = await http.post(
        Uri.parse("${ApiService.baseUrl}/insert_message_text.php"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "chat_id": chatId,
          "sender": "model",
          "type": "text",
          "content": text,
        }),
      );
      if (response.statusCode != 200) {
        throw Exception("HTTP ${response.statusCode}: ${response.body}");
      }

      final data = jsonDecode(response.body);

      if (!data['success']) debugPrint("Erreur insertion texte: ${data['message']}");
    } catch (e) {
      debugPrint("Erreur envoi texte: $e");
    }
  }

  // NOUVELLE MÉTHODE _pickImage améliorée
Future<void> _pickImage() async {
  try {
    if (!mounted) return;

    final ImagePicker picker = ImagePicker();
    final XFile? pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 800,
      maxHeight: 800,
      imageQuality: 85,
    );

    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      if (!mounted) return;

      // Créer un chat si nécessaire
      if (currentChatId == null) {
        await _newChat();
        if (!mounted) return;
      }

      // Ajouter l'image au chat local
      setState(() {
        _imageBytes = bytes;
        _selectedFileName = pickedFile.name;
        messages.add({
          "role": "user",
          "type": "image",
          "content": base64Encode(bytes),
        });
      });

      _scrollToBottom();



      _showSnackBar('Image importée!', Colors.green);

      // Envoyer au backend
      if (currentChatId != null) {
        await _sendImageToBackend(bytes, currentChatId!);
        

      }
    } else {
      _showSnackBar('Aucune image sélectionnée', Colors.orange);
    }
  } catch (e) {
    if (mounted) _showSnackBar('Erreur: ${e.toString()}', Colors.red);
    debugPrint("Erreur _pickImage: $e");
  }
}


  Future<String?> _sendToAPI(Uint8List imageBytes) async {
  return await ApiService.sendImageToFlask(imageBytes);
  }



  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _loadArchives() async {
    try {
      final response = await http.get(Uri.parse(
        "${ApiService.baseUrl}/get_archives.php?user_id=${widget.userId}"
      ));
      if (response.statusCode != 200) {
        throw Exception("HTTP ${response.statusCode}: ${response.body}");
      }

      final data = jsonDecode(response.body);


      if (data['success']) {
        List archives = data['archives'];

        if (!mounted) return;

        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: AppColors.darkBackground,
            surfaceTintColor: Colors.transparent,
            title: const Text(
              "Archives",
              style: TextStyle(color: Colors.white, fontFamily: 'Roboto Mono'),
            ),
            content: SizedBox(
              width: double.maxFinite,
              height: MediaQuery.of(context).size.height * 0.6,
              child: ListView.builder(
                itemCount: archives.length,
                itemBuilder: (context, index) {
                  final chat = archives[index];
                  return ListTile(
                    title: Text(chat['title'], style: const TextStyle(color: Colors.white)),
                    subtitle: Text(chat['created_at'], style: TextStyle(color: AppColors.subtleText)),
                    onTap: () {
                      if (!mounted) return;
                      setState(() {
                        currentChatId = chat['id'];
                        messages.clear();
                        _imageBytes = null;
                        _selectedFileName = null;
                      });
                      _loadMessages(currentChatId!);
                      Navigator.pop(context);
                      _showSnackBar('Chat chargé: ${chat['title']}', Colors.blue);
                    },
                  );
                },
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('FERMER', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      debugPrint("Erreur chargement archives: $e");
      if (mounted) {
        _showSnackBar('Erreur chargement archives', Colors.red);
      }
    }
  }

  Future<void> _loadMessages(int chatId) async {
    try {
      final response = await http.get(Uri.parse(
          "${ApiService.baseUrl}/get_messages.php?chat_id=$chatId"));
          
      if (response.statusCode != 200) {
        throw Exception("HTTP ${response.statusCode}: ${response.body}");
      }

      final data = jsonDecode(response.body);


      if (data['success'] && mounted) {
        setState(() {
          messages = List<Map<String, String>>.from(data['messages']);
        });
        _scrollToBottom(animated: false);

      }
    } catch (e) {
      debugPrint("Erreur chargement messages: $e");
    }
  }

  void _logout() {
    if (_scaffoldKey.currentState?.isDrawerOpen ?? false) {
      Navigator.pop(context);
    }
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.darkBackground,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: AppColors.primaryColor, width: 1.5),
        ),
        title: ShaderMask(
          shaderCallback: (bounds) =>
              AppColors.primaryGradient.createShader(bounds),
          child: const Text(
            "CONFIRMER LA DÉCONNEXION",
            style: TextStyle(
              fontFamily: 'Roboto Mono',
              color: Colors.white,
              fontSize: 18,
            ),
          ),
        ),
        content: Text(
          "Êtes-vous sûr de vouloir vous déconnecter ?",
          style: TextStyle(
            fontFamily: 'Roboto Mono',
            color: AppColors.subtleText,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "ANNULER",
              style: TextStyle(
                fontFamily: 'Roboto Mono',
                color: AppColors.secondaryColor,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => LoginScreen()),
                (route) => false,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Text(
              "SE DÉCONNECTER",
              style: TextStyle(
                fontFamily: 'Montserrat',
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _navigateToProfile() {
    if (_scaffoldKey.currentState?.isDrawerOpen ?? false) {
      Navigator.pop(context);
    }
    Future.delayed(const Duration(milliseconds: 300), () {
  // Vérifie si le widget est toujours monté
  if (mounted) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProfileScreen(userId: widget.userId),
      ),
    );
  }
});
  }

  void _navigateToNewChat() {
    if (_scaffoldKey.currentState?.isDrawerOpen ?? false) {
      Navigator.pop(context);
    }
    Future.delayed(const Duration(milliseconds: 300), () {
      _newChat();
    });
  }

void _scrollToBottom({bool animated = true}) {
  if (messages.isEmpty) return; // ❌ Ne fait rien si pas de messages

  WidgetsBinding.instance.addPostFrameCallback((_) {
    if (_scrollController.hasClients) {
      final position = _scrollController.position.maxScrollExtent;

      if (animated) {
        _scrollController.animateTo(
          position,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      } else {
        _scrollController.jumpTo(position);
      }
    }
  });
}








  @override
Widget build(BuildContext context) {
  final screenWidth = MediaQuery.of(context).size.width;
  final isSmallScreen = screenWidth < 600;
  final bottomPadding = MediaQuery.of(context).padding.bottom;

  return Scaffold(
    key: _scaffoldKey,
    backgroundColor: Colors.transparent,
    drawer: isSmallScreen
        ? Drawer(
            width: screenWidth * 0.85,
            backgroundColor: Colors.transparent,
            child: Container(
              decoration: HomeStyle.backgroundDecoration,
              child: SidebarWidget(
                isVisible: true,
                onNewChat: _navigateToNewChat,
                onOpenProfile: _navigateToProfile,
                onLogout: _logout,
                onViewArchives: _loadArchives,
              ),
            ),
          )
        : null,
    body: Container(
      decoration: HomeStyle.backgroundDecoration,
      child: Stack(
        children: [
          // CONTENU PRINCIPAL - AVEC DÉFILEMENT CORRIGÉ
          Positioned.fill(
            top: 0,
            bottom: 100 + bottomPadding,
            child: NotificationListener<ScrollNotification>(
              onNotification: (ScrollNotification notification) {
                return false;
              },
              child: Column(
  children: [
    // Si aucun message ni image, montre un texte/icone
    if (_imageBytes == null && messages.isEmpty)
      Expanded(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Aucun message pour l'instant",
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
              const SizedBox(height: 20),
              Icon(
                kIsWeb ? Icons.file_upload : Icons.image,
                size: 60,
                color: AppColors.subtleText,
              ),
            ],
          ),
        ),
      )
    else
      // Sinon montre la liste des messages
      Expanded(
        child: ListView.builder(
          controller: _scrollController,
          reverse: true,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
          itemCount: messages.length,
          itemBuilder: (context, index) {
            final msg = messages[messages.length - 1 - index];
            if (msg["type"] == "image") {
              return Align(
                alignment: msg["role"] == "user" ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.7,
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.memory(
                      base64Decode(msg["content"]!),
                      width: 220,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              );
            }
            return Align(
              alignment: msg["role"] == "user" ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width * 0.75,
                ),
                margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: msg["role"] == "user"
                      ? AppColors.applyAlpha(Colors.blue, 0.3)
                      : AppColors.applyAlpha(Colors.green, 0.3),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  msg["content"] ?? '',
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            );
          },
        ),
      ),
  ],
),

            ),
          ),

          // BARRE DE CONTRÔLE INFÉRIEURE
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.only(
                left: 15,
                right: 15,
                top: 15,
                bottom: bottomPadding + 15,
              ),
              decoration: BoxDecoration(
                color: AppColors.applyAlpha(AppColors.darkBackground, 0.95),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
                border: Border.all(
                  color: AppColors.applyAlpha(AppColors.primaryColor, 0.4),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withAlpha(179),
                    blurRadius: 25,
                    spreadRadius: 5,
                    offset: const Offset(0, -5),
                  ),
                  BoxShadow(
                    color: AppColors.primaryColor.withAlpha(51),
                    blurRadius: 20,
                    spreadRadius: 2,
                    offset: const Offset(0, 0),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      gradient: AppColors.primaryGradient,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.primaryColor.withAlpha(128),
                          blurRadius: 15,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: IconButton(
                      icon: const Icon(
                        Icons.menu_rounded,
                        color: Colors.white,
                        size: 26,
                      ),
                      onPressed: () {
                        if (isSmallScreen) {
                          _scaffoldKey.currentState?.openDrawer();
                        } else {
                          showDialog(
                            context: context,
                            builder: (context) => Dialog(
                              backgroundColor: Colors.transparent,
                              insetPadding: const EdgeInsets.only(left: 20),
                              child: Container(
                                width: HomeStyle.sidebarWidth,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(16),
                                  color: AppColors.applyAlpha(
                                    AppColors.darkBackground,
                                    0.95,
                                  ),
                                  border: Border.all(
                                    color: AppColors.primaryColor,
                                    width: 1.5,
                                  ),
                                ),
                                child: SidebarWidget(
                                  isVisible: true,
                                  onNewChat: () {
                                    Navigator.pop(context);
                                    _navigateToNewChat();
                                  },
                                  onOpenProfile: () {
                                    Navigator.pop(context);
                                    _navigateToProfile();
                                  },
                                  onLogout: () {
                                    Navigator.pop(context);
                                    _logout();
                                  },
                                  onViewArchives: _loadArchives,
                                ),
                              ),
                            ),
                          );
                        }
                      },
                      style: IconButton.styleFrom(
                        padding: const EdgeInsets.all(12),
                      ),
                    ),
                  ),

                  const SizedBox(width: 15),

                  // ZONE FICHIER
                  Expanded(
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: () {
                          debugPrint("🖱️ InkWell cliqué!");
                          _pickImage();
                        },
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.applyAlpha(Colors.black, 0.4),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: AppColors.applyAlpha(AppColors.secondaryColor, 0.3),
                              width: 1.5,
                            ),
                          ),
                          child: Row(
                            children: [
                              // Icon(
                              //   kIsWeb ? Icons.file_upload : Icons.image_outlined,
                              //   color: AppColors.secondaryColor,
                              //   size: 22,
                              // ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _imageBytes != null
                                          ? "PRÊT POUR L'ANALYSE"
                                          : "IMPORTER UNE IMAGE",
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontFamily: 'Roboto Mono',
                                        color: AppColors.subtleText,
                                        letterSpacing: 1.2,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      _selectedFileName ?? 
                                      (kIsWeb ? "Cliquer pour importer" : "Sélectionner une image"),
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontFamily: 'Roboto Mono',
                                        color: Colors.white,
                                        fontWeight: FontWeight.w500,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                              if (_imageBytes != null)
                                Container(
                                  margin: const EdgeInsets.only(left: 10),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 5,
                                  ),
                                  decoration: BoxDecoration(
                                    color: AppColors.applyAlpha(
                                      AppColors.primaryColor,
                                      0.2,
                                    ),
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color: AppColors.primaryColor,
                                      width: 1,
                                    ),
                                  ),
                                  child: Text(
                                    "READY",
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontFamily: 'Roboto Mono',
                                      color: AppColors.primaryColor,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(width: 15),

                  Container(
                    decoration: BoxDecoration(
                      gradient: _imageBytes != null 
                          ? AppColors.primaryGradient
                          : LinearGradient(colors: [Colors.grey.shade800, Colors.grey.shade800]),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: (_imageBytes != null 
                              ? AppColors.primaryColor 
                              : Colors.grey).withAlpha(204),
                          blurRadius: 20,
                          spreadRadius: 3,
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                      onPressed: _imageBytes != null
                      ? () async {
                          debugPrint("🚀 Envoi image au modèle Flask...");

                          if (_imageBytes == null) return;

                          final caption = await _sendToAPI(_imageBytes!);

                          if (caption != null && mounted) {
                            debugPrint("✅ Caption reçue: $caption");

                            // Ajouter le message
                            setState(() {
  messages.add({
    "role": "model",
    "type": "text",
    "content": caption,
  });
});

// Scroll automatiquement à la fin
WidgetsBinding.instance.addPostFrameCallback((_) {
  if (_scrollController.hasClients) {
    _scrollController.animateTo(
      _scrollController.position.maxScrollExtent,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }
});


                            // Sauvegarde en base
                            if (currentChatId != null) {
                              await _sendTextToBackend(caption, currentChatId!);
                            }
                          } else {
                            debugPrint("❌ Aucune réponse du modèle");
                          }
                        }
                      : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 25,
                          vertical: 14,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        disabledBackgroundColor: Colors.grey.shade800.withAlpha(128),
                        disabledForegroundColor: Colors.grey.shade500,
                      ),
                      child: const Icon(
                        Icons.search_rounded,
                        size: 24,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
  // ✅ ICI EXACTEMENT
  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
 
}