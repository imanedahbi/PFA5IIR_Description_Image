import 'package:flutter/material.dart';
import 'login_screen.dart';
import '../services/api_service.dart';
// Import des styles
import '../styles/app_colors.dart';
import '../styles/signup_style.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nomController = TextEditingController();
  final TextEditingController _prenomController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  Future<void> _signUp() async {
    // LOGIQUE BACKEND INTACTE ET SÉCURISÉE
    if (_formKey.currentState!.validate()) {
      final result = await ApiService.signUp({
        'nom': _nomController.text.trim(),
        'prenom': _prenomController.text.trim(),
        'username': _usernameController.text.trim(),
        'email': _emailController.text.trim(),
        'password': _passwordController.text.trim(),
      });

      if (!mounted) return;

      if (result['success'] == true) {
        // Après l'inscription, rediriger vers le login
        // car nous n'avons pas d'ID utilisateur après signup
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
        );
        
        // Afficher un message de succès
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Compte créé avec succès ! Veuillez vous connecter.'),
            backgroundColor: Colors.green,
          ),
        );
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(result['message'] ?? 'Erreur inconnue')));
      }
    }
  }
  // FIN LOGIQUE BACKEND

  @override
  void dispose() {
    _nomController.dispose();
    _prenomController.dispose();
    _usernameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SignUpStyles.backgroundColor,
      body: SafeArea(
        child: Container(
          decoration: SignUpStyles.backgroundDecoration,
          child: Padding(
            padding: const EdgeInsets.all(SignUpStyles.defaultPadding),
            child: SingleChildScrollView(
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 5),  // ← Réduit à 10 (au lieu de 20)

// Logo avec effet néon identique au login - AGRANDI
Center(
  child: ShaderMask(
    shaderCallback: (bounds) =>
        AppColors.primaryGradient.createShader(bounds),
    child: Image.asset(
      'assets/images/imagerecognitionApp.png',
      width: 180,  // ← Agrandi de 150 à 180
      height: 180, // ← Agrandi de 150 à 180
      fit: BoxFit.contain,
      color: Colors.white,
    ),
  ),
),

// const SizedBox(height: 0),  // ← Supprimé (0 au lieu de 5)

// Titre CYBER SCAN AI (style identique)
Center(
  child: ShaderMask(
    shaderCallback: (bounds) =>
        AppColors.primaryGradient.createShader(bounds),
    child: const Text(
      "CYBER SCAN AI",
      style: TextStyle(
        fontSize: 30,  // ← Légèrement agrandi (32 à 34)
        fontFamily: 'Roboto Mono',
        fontWeight: FontWeight.w800,
        letterSpacing: 3.0,
        color: Colors.white,
      ),
    ),
  ),
),

// const SizedBox(height: 0),  // ← Supprimé (0 au lieu de 2)

// Sous-titre style cyberpunk
Center(
  child: Text(
    "NEW USER REGISTRATION",
    style: TextStyle(
      color: AppColors.secondaryColor,
      fontFamily: 'Roboto Mono',
      fontSize: 14,
      letterSpacing: 3.0,
      fontWeight: FontWeight.w500,
    ),
  ),
),

const SizedBox(height: 8),  // ← Réduit à 8 (au lieu de 15)

// Séparateur style scanline
                    Container(
                      height: 1,
                      margin: const EdgeInsets.symmetric(horizontal: 40),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            AppColors.primaryColor,
                            AppColors.secondaryColor,
                            AppColors.primaryColor,
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 40),

                    // Conteneur cyberpunk pour le formulaire
                    Container(
                      padding: const EdgeInsets.all(28),
                      decoration: SignUpStyles.formContainerDecoration,
                      child: Column(
                        children: [
                          // Champs de formulaire en grille pour économiser l'espace
                          Column(
                            children: [
                              // Première ligne (Nom et Prénom)
                              Row(
                                children: [
                                  Expanded(
                                    child: _buildInputField(
                                      controller: _nomController,
                                      label: 'NOM',
                                      icon: Icons.person_pin_circle_outlined,
                                      validator: (value) =>
                                          value!.isEmpty ? 'Entrez votre nom' : null,
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: _buildInputField(
                                      controller: _prenomController,
                                      label: 'PRÉNOM',
                                      icon: Icons.person_pin_outlined,
                                      validator: (value) =>
                                          value!.isEmpty ? 'Entrez votre prénom' : null,
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: SignUpStyles.mediumSpacing),

                              // Champ Username
                              _buildInputField(
                                controller: _usernameController,
                                label: 'USERNAME',
                                icon: Icons.account_circle_outlined,
                                validator: (value) => value!.isEmpty
                                    ? 'Entrez un nom d\'utilisateur'
                                    : null,
                              ),

                              const SizedBox(height: SignUpStyles.mediumSpacing),

                              // Champ Email
                              _buildInputField(
                                controller: _emailController,
                                label: 'EMAIL ADDRESS',
                                icon: Icons.alternate_email,
                                validator: (value) =>
                                    value!.isEmpty ? 'Entrez votre email' : null,
                              ),

                              const SizedBox(height: SignUpStyles.mediumSpacing),

                              // Champ Password
                              _buildInputField(
                                controller: _passwordController,
                                label: 'PASSWORD',
                                icon: Icons.vpn_key_outlined,
                                obscureText: true,
                                validator: (value) => value!.isEmpty
                                    ? 'Entrez un mot de passe'
                                    : null,
                              ),
                            ],
                          ),

                          const SizedBox(height: SignUpStyles.extraLargeSpacing),

                          // Bouton Créer le compte avec effet néon
                          SizedBox(
                            width: double.infinity,
                            child: DecoratedBox(
                              decoration: SignUpStyles.buttonDecoration,
                              child: ElevatedButton(
                                onPressed: _signUp,
                                style: SignUpStyles.primaryButtonStyle,
                                child: const Text("CREATE ACCOUNT"),
                              ),
                            ),
                          ),

                          const SizedBox(height: 25),

                          // Séparateur
                          Container(
                            height: 1,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  AppColors.primaryColor.withOpacity(0.3),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),

                          const SizedBox(height: 25),

                          // Lien vers la connexion
                          Center(
                            child: TextButton(
                              onPressed: () {
                                if (!mounted) return;
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (_) => const LoginScreen()),
                                );
                              },
                              style: SignUpStyles.secondaryButtonStyle,
                              child: const Text("HAVE AN ACCOUNT? LOGIN"),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 40),

                    // Footer style cyberpunk
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppColors.secondaryColor.withOpacity(0.2),
                          width: 1,
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Indicateur de sécurité
                          Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  gradient: AppColors.primaryGradient,
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppColors.secondaryColor
                                          .withAlpha(120),
                                      blurRadius: 6,
                                      spreadRadius: 1,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                "SECURE CONNECTION",
                                style: TextStyle(
                                  color: AppColors.subtleText,
                                  fontFamily: 'Roboto Mono',
                                  fontSize: 11,
                                  letterSpacing: 1.0,
                                ),
                              ),
                            ],
                          ),

                          
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Widget utilitaire pour les champs de texte
  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool obscureText = false,
    String? Function(String?)? validator,
  }) {
    return Container(
      decoration: SignUpStyles.formFieldBoxDecoration,
      child: TextFormField(
        controller: controller,
        obscureText: obscureText,
        style: SignUpStyles.formFieldTextStyle,
        decoration: SignUpStyles.textFieldDecoration(
          label: label,
          icon: icon,
        ),
        validator: validator,
      ),
    );
  }
}