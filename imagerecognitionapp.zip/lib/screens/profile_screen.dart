import 'package:flutter/material.dart';
import '../styles/profile_style.dart';
import '../styles/app_colors.dart';
import '../services/api_service.dart';

class ProfileScreen extends StatefulWidget {
  final int userId;

  const ProfileScreen({super.key, required this.userId});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final TextEditingController _nomController = TextEditingController();
  final TextEditingController _prenomController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _currentPasswordController = TextEditingController();
  final TextEditingController _newPasswordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  bool _isEditing = false;
  bool _isChangingPassword = false;
  bool _isLoading = true;
  Map<String, dynamic> _userData = {};

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    try {
      final result = await ApiService.getUserProfile(widget.userId);
      
      if (!mounted) return;
      
      if (result['success'] == true) {
        setState(() {
          _userData = result['user'] ?? {};
          _nomController.text = _userData['nom'] ?? '';
          _prenomController.text = _userData['prenom'] ?? '';
          _usernameController.text = _userData['username'] ?? '';
          _emailController.text = _userData['email'] ?? '';
          _isLoading = false;
        });
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'ERREUR // ${result['message'] ?? 'CHARGEMENT DU PROFIL ÉCHOUÉ'}',
              style: TextStyle(fontFamily: 'Roboto Mono'),
            ),
            backgroundColor: AppColors.errorColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
        setState(() {
          _isLoading = false;
        });
      }
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'ERREUR // PROBLÈME DE CONNEXION',
            style: TextStyle(fontFamily: 'Roboto Mono'),
          ),
          backgroundColor: AppColors.errorColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      );
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _updateProfile() async {
    if (_nomController.text.isEmpty || _prenomController.text.isEmpty || 
        _usernameController.text.isEmpty || _emailController.text.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'ERREUR // TOUS LES CHAMPS SONT REQUIS',
            style: TextStyle(fontFamily: 'Roboto Mono'),
          ),
          backgroundColor: AppColors.errorColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      );
      return;
    }

    try {
      final result = await ApiService.updateUserProfile(
        userId: widget.userId,
        nom: _nomController.text.trim(),
        prenom: _prenomController.text.trim(),
        username: _usernameController.text.trim(),
        email: _emailController.text.trim(),
      );

      if (!mounted) return;

      if (result['success'] == true) {
        setState(() {
          _isEditing = false;
          _userData['nom'] = _nomController.text.trim();
          _userData['prenom'] = _prenomController.text.trim();
          _userData['username'] = _usernameController.text.trim();
          _userData['email'] = _emailController.text.trim();
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'SUCCÈS // PROFIL MIS À JOUR',
              style: TextStyle(fontFamily: 'Roboto Mono'),
            ),
            backgroundColor: AppColors.secondaryColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'ERREUR // ${result['message'] ?? 'MISE À JOUR ÉCHOUÉE'}',
              style: TextStyle(fontFamily: 'Roboto Mono'),
            ),
            backgroundColor: AppColors.errorColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
      }
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'ERREUR // PROBLÈME DE CONNEXION',
            style: TextStyle(fontFamily: 'Roboto Mono'),
          ),
          backgroundColor: AppColors.errorColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      );
    }
  }

  Future<void> _changePassword() async {
    if (_newPasswordController.text != _confirmPasswordController.text) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'ERREUR // LES MOTS DE PASSE NE CORRESPONDENT PAS',
            style: TextStyle(fontFamily: 'Roboto Mono'),
          ),
          backgroundColor: AppColors.errorColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      );
      return;
    }

    try {
      final result = await ApiService.changePassword(
        userId: widget.userId,
        currentPassword: _currentPasswordController.text.trim(),
        newPassword: _newPasswordController.text.trim(),
      );

      if (!mounted) return;

      if (result['success'] == true) {
        setState(() {
          _isChangingPassword = false;
          _currentPasswordController.clear();
          _newPasswordController.clear();
          _confirmPasswordController.clear();
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'SUCCÈS // MOT DE PASSE MODIFIÉ',
              style: TextStyle(fontFamily: 'Roboto Mono'),
            ),
            backgroundColor: AppColors.secondaryColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'ERREUR // ${result['message'] ?? 'MODIFICATION ÉCHOUÉE'}',
              style: TextStyle(fontFamily: 'Roboto Mono'),
            ),
            backgroundColor: AppColors.errorColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        );
      }
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'ERREUR // PROBLÈME DE CONNEXION',
            style: TextStyle(fontFamily: 'Roboto Mono'),
          ),
          backgroundColor: AppColors.errorColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _nomController.dispose();
    _prenomController.dispose();
    _usernameController.dispose();
    _emailController.dispose();
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: ProfileStyles.backgroundDecoration,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(ProfileStyles.defaultPadding),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header avec effet néon
                  Container(
                    padding: const EdgeInsets.only(bottom: 20),
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: AppColors.applyAlpha(AppColors.primaryColor, 0.3),
                          width: 1.5,
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        // Bouton retour avec effet néon
                        Container(
                          decoration: BoxDecoration(
                            gradient: AppColors.primaryGradient,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primaryColor.withAlpha(128),
                                blurRadius: 15,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: IconButton(
                            onPressed: () => Navigator.pop(context),
                            icon: Icon(
                              Icons.arrow_back_ios_new_rounded,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        ),
                        
                        const SizedBox(width: 20),
                        
                        // Titre avec effet gradient
                        Expanded(
                          child: ShaderMask(
                            shaderCallback: (bounds) =>
                                AppColors.primaryGradient.createShader(bounds),
                            child: const Text(
                              "PROFIL",
                              style: TextStyle(
                                fontSize: 24,
                                fontFamily: 'Roboto Mono',
                                fontWeight: FontWeight.w800,
                                letterSpacing: 2.0,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 30),

                  // Avatar utilisateur avec effet néon
                  Center(
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: AppColors.primaryGradient,
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primaryColor.withAlpha(150),
                            blurRadius: 25,
                            spreadRadius: 3,
                          ),
                        ],
                      ),
                      child: CircleAvatar(
                        radius: 60,
                        backgroundColor: AppColors.darkBackground,
                        child: Icon(
                          Icons.person_rounded,
                          size: 70,
                          color: AppColors.primaryColor,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Nom d'utilisateur
                  Center(
                    child: Text(
                      _isLoading ? "CHARGEMENT..." : (_userData['username'] ?? 'UTILISATEUR'),
                      style: const TextStyle(
                        fontSize: 22,
                        fontFamily: 'Roboto Mono',
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),

                  Center(
                    child: Text(
                      _isLoading ? "..." : "${_userData['prenom'] ?? ''} ${_userData['nom'] ?? ''}",
                      style: TextStyle(
                        fontSize: 16,
                        fontFamily: 'Roboto Mono',
                        color: AppColors.subtleText,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // Carte d'informations utilisateur (effet cyberpunk)
                  Container(
                    decoration: ProfileStyles.cardDecoration,
                    padding: const EdgeInsets.all(ProfileStyles.defaultPadding),
                    child: _isLoading
                        ? _buildLoadingState()
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // En-tête de section
                              Row(
                                children: [
                                  Icon(
                                    Icons.badge_rounded,
                                    color: AppColors.secondaryColor,
                                    size: 20,
                                  ),
                                  const SizedBox(width: 10),
                                  ShaderMask(
                                    shaderCallback: (bounds) =>
                                        AppColors.primaryGradient.createShader(bounds),
                                    child: Text(
                                      "INFORMATIONS PERSONNELLES",
                                      style: ProfileStyles.sectionTitleStyle,
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 5),
                              Container(
                                height: 1,
                                margin: const EdgeInsets.only(bottom: 20),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.transparent,
                                      AppColors.primaryColor,
                                      Colors.transparent,
                                    ],
                                  ),
                                ),
                              ),

                              // Grille d'informations - ORGANISATION AMÉLIORÉE
                              Column(
                                children: [
                                  // Nom COMPLET (une seule ligne)
                                  _buildInfoCardEnhanced(
                                    icon: Icons.person_outline_rounded,
                                    label: "NOM COMPLET",
                                    value: "${_userData['prenom'] ?? ''} ${_userData['nom'] ?? ''}".trim(),
                                    isEditing: _isEditing,
                                    onEditNom: _nomController,
                                    onEditPrenom: _prenomController,
                                  ),

                                  const SizedBox(height: 15),

                                  // Username
                                  _buildInfoCardSingle(
                                    icon: Icons.alternate_email_rounded,
                                    label: "USERNAME",
                                    value: _userData['username'] ?? 'NON RENSEIGNÉ',
                                    controller: _usernameController,
                                    isEditing: _isEditing,
                                  ),

                                  const SizedBox(height: 15),

                                  // Email
                                  _buildInfoCardSingle(
                                    icon: Icons.email_outlined,
                                    label: "EMAIL",
                                    value: _userData['email'] ?? 'NON RENSEIGNÉ',
                                    controller: _emailController,
                                    isEditing: _isEditing,
                                    isEmail: true,
                                  ),
                                ],
                              ),

                              const SizedBox(height: 25),

                              // Boutons d'action
                              if (!_isEditing && !_isChangingPassword)
                                Column(
                                  children: [
                                    SizedBox(
                                      width: double.infinity,
                                      height: 50,
                                      child: DecoratedBox(
                                        decoration: ProfileStyles.primaryButtonDecoration,
                                        child: ElevatedButton.icon(
                                          onPressed: () {
                                            setState(() {
                                              _isEditing = true;
                                              _isChangingPassword = false;
                                            });
                                          },
                                          icon: const Icon(Icons.edit_rounded, size: 20),
                                          label: const Text("MODIFIER PROFIL"),
                                          style: ProfileStyles.primaryButtonStyle,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    SizedBox(
                                      width: double.infinity,
                                      height: 50,
                                      child: DecoratedBox(
                                        decoration: ProfileStyles.secondaryButtonDecoration,
                                        child: ElevatedButton.icon(
                                          onPressed: () {
                                            setState(() {
                                              _isChangingPassword = true;
                                              _isEditing = false;
                                            });
                                          },
                                          icon: const Icon(Icons.lock_reset_rounded, size: 20),
                                          label: const Text("CHANGER MOT DE PASSE"),
                                          style: ProfileStyles.secondaryButtonStyle,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),

                              // Boutons de confirmation édition
                              if (_isEditing)
                                Column(
                                  children: [
                                    const SizedBox(height: 10),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: SizedBox(
                                            height: 55,
                                            child: DecoratedBox(
                                              decoration: ProfileStyles.successButtonDecoration,
                                              child: ElevatedButton.icon(
                                                onPressed: _updateProfile,
                                                icon: const Icon(Icons.save_rounded, size: 20),
                                                label: const Text("SAUVEGARDER"),
                                                style: ProfileStyles.successButtonStyle,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 15),
                                        Expanded(
                                          child: SizedBox(
                                            height: 55,
                                            child: ElevatedButton.icon(
                                              onPressed: () {
                                                setState(() {
                                                  _isEditing = false;
                                                  _nomController.text = _userData['nom'] ?? '';
                                                  _prenomController.text = _userData['prenom'] ?? '';
                                                  _usernameController.text = _userData['username'] ?? '';
                                                  _emailController.text = _userData['email'] ?? '';
                                                });
                                              },
                                              icon: const Icon(Icons.close_rounded, size: 20),
                                              label: const Text("ANNULER"),
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: Colors.grey[900],
                                                foregroundColor: Colors.white,
                                                textStyle: const TextStyle(
                                                  fontFamily: 'Montserrat',
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                                shape: RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.circular(12),
                                                  side: BorderSide(
                                                    color: Colors.grey[700]!,
                                                    width: 1.5,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                            ],
                          ),
                  ),

                  // Section changement de mot de passe
                  if (_isChangingPassword) ...[
                    const SizedBox(height: 30),

                    Container(
                      decoration: ProfileStyles.cardDecoration,
                      padding: const EdgeInsets.all(ProfileStyles.defaultPadding),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // En-tête de section
                          Row(
                            children: [
                              Icon(
                                Icons.security_rounded,
                                color: AppColors.secondaryColor,
                                size: 20,
                              ),
                              const SizedBox(width: 10),
                              ShaderMask(
                                shaderCallback: (bounds) =>
                                    AppColors.primaryGradient.createShader(bounds),
                                child: Text(
                                  "SÉCURITÉ // CHANGEMENT DE MOT DE PASSE",
                                  style: ProfileStyles.sectionTitleStyle,
                                ),
                              ),
                            ],
                          ),

                          const SizedBox(height: 5),
                          Container(
                            height: 1,
                            margin: const EdgeInsets.only(bottom: 20),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  AppColors.secondaryColor,
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),

                          // Mot de passe actuel
                          Container(
                            decoration: ProfileStyles.inputContainerDecoration,
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: TextFormField(
                              controller: _currentPasswordController,
                              obscureText: true,
                              style: ProfileStyles.inputTextStyle,
                              decoration: ProfileStyles.inputDecoration.copyWith(
                                labelText: 'MOT DE PASSE ACTUEL',
                                prefixIcon: Icon(
                                  Icons.lock_outline_rounded,
                                  color: AppColors.secondaryColor,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 15),

                          // Nouveau mot de passe
                          Container(
                            decoration: ProfileStyles.inputContainerDecoration,
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: TextFormField(
                              controller: _newPasswordController,
                              obscureText: true,
                              style: ProfileStyles.inputTextStyle,
                              decoration: ProfileStyles.inputDecoration.copyWith(
                                labelText: 'NOUVEAU MOT DE PASSE',
                                prefixIcon: Icon(
                                  Icons.lock_reset_rounded,
                                  color: AppColors.secondaryColor,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 15),

                          // Confirmation nouveau mot de passe
                          Container(
                            decoration: ProfileStyles.inputContainerDecoration,
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: TextFormField(
                              controller: _confirmPasswordController,
                              obscureText: true,
                              style: ProfileStyles.inputTextStyle,
                              decoration: ProfileStyles.inputDecoration.copyWith(
                                labelText: 'CONFIRMER LE NOUVEAU MOT DE PASSE',
                                prefixIcon: Icon(
                                  Icons.lock_reset_rounded,
                                  color: AppColors.secondaryColor,
                                ),
                              ),
                            ),
                          ),

                          const SizedBox(height: 25),

                          // Boutons changement mot de passe
                          Row(
                            children: [
                              Expanded(
                                child: SizedBox(
                                  height: 55,
                                  child: DecoratedBox(
                                    decoration: ProfileStyles.successButtonDecoration,
                                    child: ElevatedButton.icon(
                                      onPressed: _changePassword,
                                      icon: const Icon(Icons.security_update_good_rounded, size: 20),
                                      label: const Text("MODIFIER MDP"),
                                      style: ProfileStyles.successButtonStyle,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 15),
                              Expanded(
                                child: SizedBox(
                                  height: 55,
                                  child: ElevatedButton.icon(
                                    onPressed: () {
                                      setState(() {
                                        _isChangingPassword = false;
                                        _currentPasswordController.clear();
                                        _newPasswordController.clear();
                                        _confirmPasswordController.clear();
                                      });
                                    },
                                    icon: const Icon(Icons.close_rounded, size: 20),
                                    label: const Text("ANNULER"),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.grey[900],
                                      foregroundColor: Colors.white,
                                      textStyle: const TextStyle(
                                        fontFamily: 'Montserrat',
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                      ),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12),
                                        side: BorderSide(
                                          color: Colors.grey[700]!,
                                          width: 1.5,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],

                  const SizedBox(height: 20),

                  // Informations système
                  Container(
                    padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppColors.applyAlpha(AppColors.primaryColor, 0.2),
                        width: 1,
                      ),
                      color: AppColors.applyAlpha(Colors.black, 0.3),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "DERNIÈRE CONNEXION",
                          style: TextStyle(
                            fontSize: 11,
                            fontFamily: 'Roboto Mono',
                            color: AppColors.subtleText,
                          ),
                        ),
                        Text(
                          "ACTIVÉ",
                          style: TextStyle(
                            fontSize: 11,
                            fontFamily: 'Roboto Mono',
                            color: AppColors.secondaryColor,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Column(
      children: [
        const SizedBox(height: 40),
        Center(
          child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(AppColors.secondaryColor),
            strokeWidth: 2,
          ),
        ),
        const SizedBox(height: 20),
        ShaderMask(
          shaderCallback: (bounds) =>
              AppColors.primaryGradient.createShader(bounds),
          child: const Text(
            "CHARGEMENT DU PROFIL...",
            style: TextStyle(
              fontFamily: 'Roboto Mono',
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }

  

  Widget _buildInfoCardSingle({
    required IconData icon,
    required String label,
    required String value,
    required TextEditingController controller,
    required bool isEditing,
    bool isEmail = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.applyAlpha(AppColors.secondaryColor, 0.2),
          width: 1.5,
        ),
        color: AppColors.applyAlpha(AppColors.darkBackground, 0.5),
      ),
      padding: const EdgeInsets.all(15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppColors.secondaryColor, size: 18),
              const SizedBox(width: 10),
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontFamily: 'Roboto Mono',
                  color: AppColors.subtleText,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (!isEditing)
            Text(
              value,
              style: const TextStyle(
                fontSize: 16,
                fontFamily: 'Roboto Mono',
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          if (isEditing)
            TextFormField(
              controller: controller,
              keyboardType: isEmail ? TextInputType.emailAddress : TextInputType.text,
              style: const TextStyle(
                fontSize: 16,
                fontFamily: 'Roboto Mono',
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
              decoration: InputDecoration(
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
                border: InputBorder.none,
                hintText: value,
                hintStyle: const TextStyle(
                  fontSize: 16,
                  fontFamily: 'Roboto Mono',
                  color: Colors.white54,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildInfoCardEnhanced({
    required IconData icon,
    required String label,
    required String value,
    required bool isEditing,
    required TextEditingController onEditNom,
    required TextEditingController onEditPrenom,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppColors.applyAlpha(AppColors.secondaryColor, 0.2),
          width: 1.5,
        ),
        color: AppColors.applyAlpha(AppColors.darkBackground, 0.5),
      ),
      padding: const EdgeInsets.all(15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppColors.secondaryColor, size: 18),
              const SizedBox(width: 10),
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontFamily: 'Roboto Mono',
                  color: AppColors.subtleText,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (!isEditing)
            Text(
              value.isEmpty ? 'NON RENSEIGNÉ' : value,
              style: const TextStyle(
                fontSize: 16,
                fontFamily: 'Roboto Mono',
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          if (isEditing)
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: onEditPrenom,
                        decoration: InputDecoration(
                          hintText: 'Prénom',
                          hintStyle: TextStyle(
                            color: AppColors.subtleText,
                            fontSize: 14,
                          ),
                          border: InputBorder.none,
                        ),
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextFormField(
                        controller: onEditNom,
                        decoration: InputDecoration(
                          hintText: 'Nom',
                          hintStyle: TextStyle(
                            color: AppColors.subtleText,
                            fontSize: 14,
                          ),
                          border: InputBorder.none,
                        ),
                        style: const TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
        ],
      ),
    );
  }
}