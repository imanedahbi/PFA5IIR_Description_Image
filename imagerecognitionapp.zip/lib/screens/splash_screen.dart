import 'package:flutter/material.dart';
import 'dart:async';
import 'package:shared_preferences/shared_preferences.dart';
import '../styles/app_colors.dart';  // Ajouté pour le gradient
import 'home_screen.dart';
import 'login_screen.dart';
import 'signup_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  final int splashDuration = 3500;

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );
    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeIn,
    );
    _controller.forward();

    // Vérification de l'état de connexion après le splash
    Timer(Duration(milliseconds: widget.splashDuration), () async {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      bool? isLoggedIn = prefs.getBool('isLoggedIn');
      bool? hasAccount = prefs.getBool('hasAccount');
      int? savedUserId = prefs.getInt('userId'); // ✅ Récupérer l'ID utilisateur sauvegardé

      Widget nextPage;
      
      if (isLoggedIn == true && savedUserId != null) {
        // Si l'utilisateur est connecté ET on a son ID
        nextPage = HomeScreen(userId: savedUserId); // ✅ Passer l'ID utilisateur
      } else if (hasAccount == true) {
        // Si l'utilisateur a un compte mais n'est pas connecté
        nextPage = const LoginScreen();
      } else {
        // Nouvel utilisateur
        nextPage = const SignUpScreen();
      }

      if (!mounted) return;

      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          transitionDuration: const Duration(milliseconds: 600),
          pageBuilder: (_, __, ___) => nextPage,
          transitionsBuilder: (_, animation, __, child) {
            return FadeTransition(opacity: animation, child: child);
          },
        ),
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Fond blanc
      body: Center(
        child: FadeTransition(
          opacity: _animation,
          child: ShaderMask(
            shaderCallback: (bounds) =>
                AppColors.primaryGradient.createShader(bounds),
            child: SizedBox(
              width: 350,
              height: 350,
              child: ClipOval(
                child: Image.asset(
                  'assets/images/imagerecognitionApp.png',
                  fit: BoxFit.cover,
                  color: Colors.white, // Important pour l'effet gradient
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}