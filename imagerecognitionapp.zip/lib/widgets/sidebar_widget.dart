import 'package:flutter/material.dart';
import '../styles/sidebar_style.dart';
import '../styles/app_colors.dart';

class SidebarWidget extends StatelessWidget {
  final bool isVisible;
  final VoidCallback onNewChat;
  final VoidCallback onOpenProfile;
  final VoidCallback onLogout;
  final VoidCallback onViewArchives;


  const SidebarWidget({
    super.key,
    required this.isVisible,
    required this.onNewChat,
    required this.onOpenProfile,
    required this.onLogout,
    required this.onViewArchives,

  });

  @override
  Widget build(BuildContext context) {
    if (!isVisible) return const SizedBox.shrink();

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      width: SidebarStyles.sidebarWidth,
      height: double.infinity,
      decoration: SidebarStyles.sidebarDecoration,
      padding: const EdgeInsets.symmetric(
        vertical: SidebarStyles.defaultPadding * 1.5,
        horizontal: SidebarStyles.defaultPadding,
      ),
      child: SingleChildScrollView( // ← AJOUTER SingleChildScrollView
       physics: const BouncingScrollPhysics(), 
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      // Logo avec effet néon
      Center(
        child: ShaderMask(
          shaderCallback: (bounds) =>
              AppColors.primaryGradient.createShader(bounds),
          child: Image.asset(
            'assets/images/imagerecognitionApp.png',
            width: 100,
            height: 100,
            fit: BoxFit.contain,
            color: Colors.white,
          ),
        ),
      ),

      const SizedBox(height: 20),

      // Titre du panneau
      Center(
        child: ShaderMask(
          shaderCallback: (bounds) =>
              AppColors.primaryGradient.createShader(bounds),
          child: const Text(
            "CONTROL PANEL",
            style: TextStyle(
              fontSize: 18,
              fontFamily: 'Roboto Mono',
              fontWeight: FontWeight.w800,
              letterSpacing: 3.0,
              color: Colors.white,
            ),
          ),
        ),
      ),

      const SizedBox(height: SidebarStyles.defaultPadding),

      // Séparateur style scanline
      Container(
        height: 1,
        margin: const EdgeInsets.only(bottom: SidebarStyles.defaultPadding),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.transparent,
              AppColors.primaryColor,
              AppColors.secondaryColor,
              AppColors.primaryColor,
              Colors.transparent,
            ],
          ),
        ),
      ),

      // Section MENU
      Text(
        "MENU PRINCIPAL",
        style: TextStyle(
          color: AppColors.subtleText,
          fontFamily: 'Roboto Mono',
          fontSize: 11,
          letterSpacing: 2.0,
          fontWeight: FontWeight.w500,
        ),
      ),

      const SizedBox(height: 15),

      // Bouton Nouveau Chat
      // _SidebarMenuItem(
      //   icon: Icons.add_circle_outline_rounded,
      //   label: "NOUVEAU SCAN",
      //   onTap: onNewChat,
      // ),

      const SizedBox(height: SidebarStyles.itemSpacing),

      // Bouton ARCHIVES
      // _SidebarMenuItem(
      //   icon: Icons.history_toggle_off_rounded,
      //   label: "ARCHIVES",
      //   onTap: onViewArchives,
      // ),

      const SizedBox(height: SidebarStyles.itemSpacing),

      // Bouton Profil
      _SidebarMenuItem(
        icon: Icons.person_2_outlined,
        label: "PROFIL UTILISATEUR",
        onTap: onOpenProfile,
      ),

      const SizedBox(height: SidebarStyles.itemSpacing),

      // Bouton Paramètres
      // _SidebarMenuItem(
      //   icon: Icons.settings_input_component_outlined,
      //   label: "PARAMÈTRES",
      //   onTap: () {
      //     ScaffoldMessenger.of(context).showSnackBar(
      //       SnackBar(
      //         content: Text(
      //           'PARAMÈTRES // FEATURE EN DÉVELOPPEMENT',
      //           style: TextStyle(
      //             fontFamily: 'Roboto Mono',
      //             fontWeight: FontWeight.w500,
      //           ),
      //         ),
      //         backgroundColor: AppColors.secondaryColor,
      //         shape: RoundedRectangleBorder(
      //           borderRadius: BorderRadius.circular(12),
      //         ),
      //       ),
      //     );
      //   },
      // ),

      const SizedBox(height: SidebarStyles.itemSpacing * 2),

      // Bouton Se déconnecter
      _SidebarMenuItem(
        icon: Icons.logout_rounded,
        label: "SE DÉCONNECTER",
        onTap: onLogout,
      ),

      const SizedBox(height: 30), // ← REMPLACER Spacer() par SizedBox

      // Section INFOS SYSTÈME
      Text(
        "STATUT SYSTÈME",
        style: TextStyle(
          color: AppColors.subtleText,
          fontFamily: 'Roboto Mono',
          fontSize: 11,
          letterSpacing: 2.0,
          fontWeight: FontWeight.w500,
        ),
      ),

      const SizedBox(height: 15),

      Container(
        padding: const EdgeInsets.all(SidebarStyles.defaultPadding),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: AppColors.applyAlpha(AppColors.secondaryColor, 0.4),
            width: 1.5,
          ),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppColors.applyAlpha(AppColors.darkBackground, 0.8),
              AppColors.applyAlpha(AppColors.darkBackground, 0.4),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: AppColors.applyAlpha(AppColors.primaryColor, 0.1),
              blurRadius: 15,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Indicateur de connexion
            Row(
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: AppColors.primaryGradient,
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.secondaryColor.withAlpha(180),
                        blurRadius: 10,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    "CONNEXION ACTIVE",
                    style: TextStyle(
                      color: AppColors.secondaryColor,
                      fontFamily: 'Roboto Mono',
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 12),

            // Serveur status
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  margin: const EdgeInsets.only(left: 1),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: AppColors.primaryGradient,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  "SERVEUR: ONLINE",
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Roboto Mono',
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 8),

            // API Status
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  margin: const EdgeInsets.only(left: 1),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: AppColors.primaryGradient,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  "API: RESPONSIVE",
                  style: TextStyle(
                    color: Colors.white,
                    fontFamily: 'Roboto Mono',
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 15),

            // Séparateur
            Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    AppColors.applyAlpha(AppColors.primaryColor, 0.3),
                    Colors.transparent,
                  ],
                ),
              ),
            ),

            const SizedBox(height: 10),

            // Version
            Center(
              child: Text(
                " CYBER SCAN AI",
                style: TextStyle(
                  color: AppColors.subtleText,
                  fontFamily: 'Roboto Mono',
                  fontSize: 10,
                  letterSpacing: 1.5,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          ],
        ),
      ),
      
      const SizedBox(height: 20), // ← ESPACE ADDITIONNEL EN BAS
    ],
  ),
),
    );
  }
}

// Widget pour les items du menu avec effet de survol cyberpunk
class _SidebarMenuItem extends StatefulWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _SidebarMenuItem({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  State<_SidebarMenuItem> createState() => _SidebarMenuItemState();
}

class _SidebarMenuItemState extends State<_SidebarMenuItem> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: _isHovered
            ? SidebarStyles.menuItemHoverDecoration
            : SidebarStyles.menuItemDecoration,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: widget.onTap,
            borderRadius: BorderRadius.circular(10),
            child: Container(
              padding: const EdgeInsets.symmetric(
                vertical: 14,
                horizontal: 16,
              ),
              child: Row(
                children: [
                  // Icône avec effet néon au survol
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: _isHovered
                          ? AppColors.applyAlpha(AppColors.primaryColor, 0.2)
                          : Colors.transparent,
                      border: Border.all(
                        color: _isHovered
                            ? AppColors.primaryColor
                            : Colors.transparent,
                        width: 1,
                      ),
                    ),
                    child: Icon(
                      widget.icon,
                      color: _isHovered
                          ? AppColors.secondaryColor
                          : SidebarStyles.iconColor,
                      size: SidebarStyles.iconSize,
                    ),
                  ),
                  
                  const SizedBox(width: 16),
                  
                  // Texte du menu
                  Expanded(
                    child: Text(
                      widget.label,
                      style: _isHovered
                          ? SidebarStyles.menuItemHoverTextStyle
                          : SidebarStyles.menuItemTextStyle,
                    ),
                  ),
                  
                  // Indicateur de sélection (flèche cyberpunk)
                  if (_isHovered)
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: AppColors.primaryGradient,
                      ),
                      child: const Icon(
                        Icons.arrow_forward_ios_rounded,
                        color: Colors.white,
                        size: 12,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}