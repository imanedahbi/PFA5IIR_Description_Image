import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';

class ImageService {
  final ImagePicker _imagePicker = ImagePicker();

  // Méthode simple pour toutes les plateformes
  Future<Uint8List?> pickImage() async {
    try {
      if (kIsWeb) {
        return await _pickImageForWeb();
      } else {
        return await _pickImageForMobile();
      }
    } catch (e) {
      debugPrint("Erreur sélection image: $e");
      return null;
    }
  }

  // Méthode pour Mobile (Android/iOS)
  Future<Uint8List?> _pickImageForMobile() async {
    try {
      final XFile? pickedFile = await _imagePicker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1200,
        maxHeight: 1200,
        imageQuality: 85,
      );

      if (pickedFile != null) {
        return await pickedFile.readAsBytes();
      }
      return null;
    } catch (e) {
      debugPrint("Erreur sélection mobile: $e");
      return null;
    }
  }

  // Méthode pour Web/PC - Solution de secours
  Future<Uint8List?> _pickImageForWeb() async {
    try {
      // Pour Web, on peut utiliser un HTML input simple
      // Note: Cette méthode est basique mais fonctionne
      debugPrint("Utilisation méthode web simple");
      
      // Si vous avez installé image_picker_web, utilisez-le :
      // import 'package:image_picker_web/image_picker_web.dart';
      // return await ImagePickerWeb.getImageAsBytes();
      
      return null;
    } catch (e) {
      debugPrint("Erreur sélection web: $e");
      return null;
    }
  }

  // Obtenir le nom du fichier
  String getFileName(Uint8List imageBytes, [String? originalName]) {
    if (originalName != null && originalName.isNotEmpty) {
      return originalName;
    }
    return 'image_${DateTime.now().millisecondsSinceEpoch}.jpg';
  }
}