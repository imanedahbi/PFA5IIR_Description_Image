import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart'; 
class ApiService {

 // Détection automatique de la plateforme
static String get baseUrl {
  if (kIsWeb) {
    // Flutter Web + XAMPP local
    return "http://127.0.0.1/imagerecognitionapp";
  } else {
    // Téléphone physique sur le même réseau
    return "http://172.20.40.81/imagerecognitionapp";
  }
}


  // URL du serveur Flask
  static String get flaskUrl {
  if (kIsWeb) {
    // Flutter Web + Flask sur la même machine
    return "http://127.0.0.1:5000";
  } else {
    // Android Emulator
    return "http://172.20.40.81:5000";
  }
}


  /// Envoyer une image au modèle Flask et récupérer le résultat
static Future<String?> sendImageToFlask(Uint8List imageBytes) async {
  try {
    final uri = Uri.parse("$flaskUrl/predict");
    final request = http.MultipartRequest("POST", uri);

    request.files.add(
      http.MultipartFile.fromBytes(
        'image',
        imageBytes,
        filename: "upload_${DateTime.now().millisecondsSinceEpoch}.jpg",
      ),
    );

    final response = await request.send();

    if (response.statusCode == 200) {
      final body = await response.stream.bytesToString();
      final data = jsonDecode(body);
      return data['caption']; // ou 'result' selon la clé que renvoie ton Flask
    } else {
      return "Erreur serveur : ${response.statusCode}";
    }
  } catch (e) {
    return "Erreur : $e";
  }
}



static Future<Map<String, dynamic>> sendImageToBackend(
    Uint8List imageBytes, int chatId, int userId) async {
  try {
    var request = http.MultipartRequest(
      "POST",
      Uri.parse("$baseUrl/insert_message.php"),
    );
    request.fields['chat_id'] = chatId.toString();
    request.fields['user_id'] = userId.toString();
    request.files.add(http.MultipartFile.fromBytes(
      'image',
      imageBytes,
      filename: "upload_${DateTime.now().millisecondsSinceEpoch}.jpg",
    ));

    final response = await request.send();
    final respStr = await response.stream.bytesToString();
    return jsonDecode(respStr);
  } catch (e) {
    return {"success": false, "message": e.toString()};
  }
}


  static Future<Map<String, dynamic>> signUp(Map<String, dynamic> data) async {
    final url = Uri.parse("$baseUrl/signup.php");
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(data),
    );
    return jsonDecode(response.body);
  }

  // ⚡ Nouvelle méthode pour login
  static Future<Map<String, dynamic>> login(String email, String password) async {
    final url = Uri.parse("$baseUrl/login.php");
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "email": email,
          "password": password,
        }),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {
          "success": false,
          "message": jsonDecode(response.body)['message'] ?? 'Erreur serveur'
        };
      }
    } catch (e) {
      return {
        "success": false,
        "message": "Impossible de se connecter au serveur : $e"
      };
    }
  }

// ✅ NOUVELLE MÉTHODE : Récupérer le profil utilisateur
  static Future<Map<String, dynamic>> getUserProfile(int userId) async {
    final url = Uri.parse("$baseUrl/get_profile.php");
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({'user_id': userId}),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {
          "success": false,
          "message": "Erreur serveur: ${response.statusCode}"
        };
      }
    } catch (e) {
      return {
        "success": false,
        "message": "Impossible de se connecter au serveur : $e"
      };
    }
  }

  // ✅ NOUVELLE MÉTHODE : Mettre à jour le profil utilisateur
  static Future<Map<String, dynamic>> updateUserProfile({
    required int userId,
    required String nom,
    required String prenom,
    required String username,
    required String email,
  }) async {
    final url = Uri.parse("$baseUrl/update_profile.php");
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          'user_id': userId,
          'nom': nom,
          'prenom': prenom,
          'username': username,
          'email': email,
        }),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {
          "success": false,
          "message": "Erreur serveur: ${response.statusCode}"
        };
      }
    } catch (e) {
      return {
        "success": false,
        "message": "Impossible de se connecter au serveur : $e"
      };
    }
  }

  // ✅ NOUVELLE MÉTHODE : Changer le mot de passe
  static Future<Map<String, dynamic>> changePassword({
    required int userId,
    required String currentPassword,
    required String newPassword,
  }) async {
    final url = Uri.parse("$baseUrl/change_password.php");
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          'user_id': userId,
          'current_password': currentPassword,
          'new_password': newPassword,
        }),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        return {
          "success": false,
          "message": "Erreur serveur: ${response.statusCode}"
        };
      }
    } catch (e) {
      return {
        "success": false,
        "message": "Impossible de se connecter au serveur : $e"
      };
    }
  }
  
}
